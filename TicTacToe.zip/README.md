#Tic Tac Toe

Using - Standalone React v 1.0.5 - Webpack version

1. Use Technologies
    - Modular SCSS / SASS
    - React 18 
    - Join Classes / Util
    - Webpack

Project name : 'Tic Tac Toe'
 
Description :

    - Tic Tac Toe is the most simple game but you will understand how react works in different aspect of rendering by using complex decision structure, I add Modular SCSS as an Alternative way of styling.
    I made a modular SCSS like a bootstrap structure.

    - I made a standalone react template on my own with a power of sass and modular sass and just like a vite structure.

    





