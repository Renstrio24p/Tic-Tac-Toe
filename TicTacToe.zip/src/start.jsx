import React from 'react';
import TicTacToe from './Tic Tac Toe/TicTacToe';

export default function Start() {
    document.title = 'Tik Tac Toe' // document title for this project

    return (
        <TicTacToe /> // Project
    )
}
// this will serve as the APP.JS
